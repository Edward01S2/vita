# README #

A shortcodes plugin for WordPress. Works great for integration in [Themewich WordPress Themes](http://themewich.com)