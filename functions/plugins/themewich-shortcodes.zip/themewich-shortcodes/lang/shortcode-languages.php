<?php


/**
 * Language Strings for Shortcodes
 * @since  v1.0
 */
/*$strings = 'tinyMCE.addI18n({' . _WP_Editors::$mce_locale . ':{
    accordion_dlg:{
        title: "' . esc_js( __( 'Title', 'framework' ) ) . '",
        content: "' . esc_js( __( 'Content', 'framework' ) ) . '"
    }
	
}})';*/
